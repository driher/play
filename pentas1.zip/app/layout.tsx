import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import NavBar from "@/components/NavBar";
import BreakingNewsBar from "@/components/BreakingNewsBar";
import Footer from "@/components/Footer";
import Script from "next/script";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

/* =========================
   SEO META GLOBAL (GOOGLE DISCOVER READY)
========================= */
export const metadata: Metadata = {
  metadataBase: new URL("https://web.pentas.tv"),

  title: {
    default: "Pentas TV - Portal Berita Terpercaya Indonesia",
    template: "%s | Pentas TV",
  },

  description:
    "Portal berita terkini, politik, ekonomi, teknologi, dan lifestyle Indonesia. Update cepat, akurat, dan terpercaya.",

  keywords: [
    "berita indonesia",
    "portal berita",
    "berita terbaru",
    "pentas tv",
    "breaking news",
    "politik indonesia",
    "ekonomi indonesia",
    "teknologi",
  ],

  authors: [{ name: "Pentas TV" }],
  creator: "Pentas TV",
  publisher: "Pentas TV",

  applicationName: "Pentas TV",

  alternates: {
    canonical: "https://web.pentas.tv",
  },

  openGraph: {
    type: "website",
    locale: "id_ID",
    url: "https://web.pentas.tv",
    siteName: "Pentas TV",
    title: "Pentas TV - Portal Berita Terpercaya Indonesia",
    description:
      "Berita terbaru Indonesia hari ini. Update cepat, akurat, dan terpercaya.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Pentas TV",
      },
    ],
  },

  twitter: {
    card: "summary_large_image",
    title: "Pentas TV - Portal Berita",
    description: "Berita terbaru Indonesia hari ini",
    images: ["/og-image.jpg"],
  },

  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },

  icons: {
    icon: "/favicon.ico",
  },
};


export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="id"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        {/* SEO tambahan manual (penting untuk Google Discover) */}
        <meta name="theme-color" content="#dc2626" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="format-detection" content="telephone=no" />

        {/* Preconnect (speed boost SEO ranking) */}
        <link rel="preconnect" href="https://cms.pentas.tv" />
        <link rel="dns-prefetch" href="https://cms.pentas.tv" />
      </head>

      <body className="min-h-full flex flex-col bg-white text-gray-900">
        {/* GLOBAL NAVBAR */}
        <NavBar />

        {/* BREAKING NEWS */}
        <BreakingNewsBar />

        {/* CONTENT */}
        <main className="flex-1">{children}</main>

<Script
  strategy="afterInteractive"
  src="https://www.googletagmanager.com/gtag/js?id=G-DEXX0XSCKX"
/>

<Script id="ga" strategy="afterInteractive">
{`
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-DEXX0XSCKX');
`}
</Script>

        {/* FOOTER */}
        <Footer />
      </body>
    </html>
  );
}