const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "cms.pentas.tv",
      },
      {
        protocol: "https",
        hostname: "cms.pentas.tv",
      },
    ],
  },

};

module.exports = nextConfig;