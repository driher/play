import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    domains: ["cms.pentas.tv"],
  },
};

export default nextConfig;